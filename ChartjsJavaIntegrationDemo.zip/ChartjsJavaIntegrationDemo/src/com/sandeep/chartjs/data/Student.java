package com.sandeep.chartjs.data;

public class Student {
	private String name;
	private int mathematicsMark;
	private int computerMark;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMathematicsMark() {
		return mathematicsMark;
	}
	public void setMathematicsMark(int mathematicsMark) {
		this.mathematicsMark = mathematicsMark;
	}
	public int getComputerMark() {
		return computerMark;
	}
	public void setComputerMark(int computerMark) {
		this.computerMark = computerMark;
	}
}
